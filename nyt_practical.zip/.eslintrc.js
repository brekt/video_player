module.exports = {
  "extends": "google",
  "parserOptions": {
    "ecmaVersion": 6,
    "sourceType": "module"
  }
};
